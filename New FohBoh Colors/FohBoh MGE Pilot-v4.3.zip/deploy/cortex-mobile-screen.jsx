// Cortex mobile screen — mounts inside IOSDevice from ios-frame.jsx · v4 design language
const { IOSDevice } = window;
const F = "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Helvetica Neue', sans-serif";
const FD = "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', sans-serif";
const A = {
  bg: '#faf9f6', text: '#0a0a0a', card: '#ffffff',
  acc: '#6D28D9', acc100: '#f4effc', acc200: '#e9defa', acc700: '#4c1d95', acc900: '#2e1065',
  n300: '#e4e4e9', n400: '#d6d6dc', n500: '#a2a2a9', n600: '#6e6e73',
  red: '#DC3545', red100: '#fbeef0'
};
const hairline = `1px solid ${A.n300}`;
const cardShadow = '0 1px 2px rgba(0,0,0,.04), 0 6px 20px rgba(0,0,0,.05)';

function Chip({ label, dot }) {
  return (
    <span style={{ fontFamily: F, display: 'inline-flex', alignItems: 'center', gap: 7, border: hairline, padding: '8px 14px', fontSize: 12.5, fontWeight: 500, color: A.text, background: A.card, whiteSpace: 'nowrap', borderRadius: 980, boxShadow: '0 1px 2px rgba(0,0,0,.03)' }}>
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: dot || A.acc, flex: 'none' }}></span>{label}
    </span>
  );
}

function Cite({ children }) {
  return <span style={{ fontSize: 10, fontWeight: 600, color: A.acc700, background: A.acc100, border: `1px solid ${A.acc200}`, padding: '3px 9px', borderRadius: 980 }}>{children}</span>;
}

function ScoreRing({ score }) {
  const r = 21, c = 2 * Math.PI * r, frac = score / 100;
  return (
    <svg width="52" height="52" viewBox="0 0 52 52" style={{ flex: 'none' }}>
      <circle cx="26" cy="26" r={r} fill="none" stroke={A.n300} strokeWidth="4" />
      <circle cx="26" cy="26" r={r} fill="none" stroke={A.acc} strokeWidth="4" strokeLinecap="round"
        strokeDasharray={`${c * frac} ${c}`} transform="rotate(-90 26 26)" />
      <text x="26" y="30" textAnchor="middle" style={{ fontFamily: FD, fontSize: 15, fontWeight: 700, fill: A.text }}>{score}</text>
    </svg>
  );
}

function CortexPhone() {
  return (
    <IOSDevice title="">
      <div style={{ fontFamily: F, background: A.bg, minHeight: '100%', display: 'flex', flexDirection: 'column', padding: '6px 16px 16px', boxSizing: 'border-box', color: A.text, WebkitFontSmoothing: 'antialiased' }}>
        {/* Large title */}
        <div style={{ padding: '6px 2px 12px' }}>
          <div style={{ fontFamily: FD, fontWeight: 700, fontSize: 24, letterSpacing: '-.02em', lineHeight: 1.1 }}>FohBoh <span style={{ color: A.n500, fontWeight: 400 }}>|</span> Cortex<span style={{ fontSize: 12, verticalAlign: 'super' }}>™</span></div>
          <div style={{ fontSize: 11, color: A.n600, marginTop: 2, fontWeight: 500 }}>Certified operations intelligence</div>
        </div>
        {/* Certified context card */}
        <div style={{ background: A.card, borderRadius: 18, boxShadow: cardShadow, padding: '12px 14px', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
          <ScoreRing score={87} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
              <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.05em', color: '#007a7a', background: '#dff4f4', padding: '3px 9px', borderRadius: 980 }}>CERTIFIED</span>
              <span style={{ fontSize: 10, color: A.n500 }}>CRT-2026-0845 · sealed 05/04</span>
            </div>
            <div style={{ fontSize: 11, color: A.n600, marginTop: 5, lineHeight: 1.5 }}>POS ✓ · Labor ✓ · Menu ✓ · <span style={{ color: A.red, fontWeight: 600 }}>Inventory held (72)</span></div>
          </div>
        </div>
        {/* Focus this week — set in the portal */}
        <div style={{ background: A.card, borderRadius: 18, boxShadow: cardShadow, padding: '11px 14px 12px', marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.08em', color: '#4c1d95' }}>FOCUS THIS WEEK</span>
            <span style={{ fontSize: 9, color: A.n500 }}>set in the portal · expires Sun</span>
          </div>
          {[
            ['1', 'Reconcile inventory counts', 'Clears the Inventory hold (TS 72)'],
            ['2', 'Food cost +3.4 pts — review protein invoices', 'Invoice prices up 6% vs the vaulted baseline']
          ].map(([n, t, w]) => (
            <div key={n} style={{ display: 'flex', gap: 9, alignItems: 'flex-start', background: A.bg, borderRadius: 11, padding: '8px 10px', marginTop: 6 }}>
              <span style={{ flex: 'none', width: 17, height: 17, borderRadius: '50%', background: '#6D28D9', color: '#fff', fontSize: 9.5, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{n}</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 11.5, fontWeight: 600, lineHeight: 1.3 }}>{t}</div>
                <div style={{ fontSize: 10, color: A.n600, marginTop: 1, lineHeight: 1.4 }}>{w}</div>
                <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: '.08em', color: '#4c1d95', marginTop: 4 }}>ASSIGNED · D. MARSH (REGIONAL)</div>
              </div>
            </div>
          ))}
        </div>
        {/* Conversation */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10, overflow: 'hidden' }}>
          <div style={{ alignSelf: 'flex-end', maxWidth: '80%', background: A.acc, color: '#fff', padding: '10px 14px', fontSize: 13.5, lineHeight: 1.45, borderRadius: '18px 18px 5px 18px', boxShadow: '0 1px 2px rgba(0,0,0,.08)', fontWeight: 700 }}>
            Why is food cost running high this week?
          </div>
          <div style={{ alignSelf: 'flex-start', maxWidth: '94%', background: A.card, padding: '12px 14px', fontSize: 13, lineHeight: 1.55, borderRadius: '18px 18px 18px 5px', boxShadow: cardShadow }}>
            Food cost is running <strong>3.4 points over target</strong> this week. Two certified drivers:
            <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4 }}>
              <div style={{ display: 'flex', gap: 8 }}><span style={{ color: A.acc, fontWeight: 700 }}>1</span><span>Protein invoice prices up 6% vs the vaulted baseline</span></div>
              <div style={{ display: 'flex', gap: 8 }}><span style={{ color: A.acc, fontWeight: 700 }}>2</span><span>Waste-log variance concentrated in prep (Tue / Wed)</span></div>
            </div>
            <div style={{ borderTop: hairline, marginTop: 10, paddingTop: 9, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              <Cite>KPI-04 Food Cost % · Vault v1.2.0</Cite>
              <Cite>POS/Sales · TS 91 ↗</Cite>
            </div>
          </div>
          <div style={{ alignSelf: 'flex-start', fontSize: 10, color: A.n500, paddingLeft: 4 }}>Certified Vault data only · Trust Wall 2 · read-only</div>
        </div>
        {/* Prompt chips */}
        <div style={{ display: 'flex', gap: 7, overflowX: 'auto', padding: '12px 0 10px', WebkitOverflowScrolling: 'touch' }}>
          <Chip label="Which dayparts are overstaffed?" />
          <Chip label="Which menu items should I reprice?" />
          <Chip label="Inventory variance?" dot={A.red} />
        </div>
        {/* Ask bar */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, border: hairline, background: A.card, padding: '10px 8px 10px 15px', fontSize: 13.5, color: A.n500, borderRadius: 980, boxShadow: '0 1px 2px rgba(0,0,0,.03)' }}>
            <span style={{ flex: 1 }}>Ask anything certified…</span>
            <button title="Voice — hands-free during service" style={{ border: 'none', background: 'transparent', color: A.acc, padding: '2px 6px', cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
            </button>
          </div>
          <button style={{ border: 'none', background: A.acc, color: '#fff', width: 42, height: 42, borderRadius: '50%', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 6px rgba(109,40,217,.35)', flex: 'none' }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 14 0"/><path d="m13 6 6 6-6 6"/></svg>
          </button>
        </div>
        <div style={{ fontSize: 9.5, color: A.n500, textAlign: 'center', marginTop: 8 }}>Voice-enabled · certified data only (TS ≥ 85) · every answer cites · Cortex cannot alter a certified result</div>
      </div>
    </IOSDevice>
  );
}
window.CortexPhone = CortexPhone;
