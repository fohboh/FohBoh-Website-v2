# GAP Analysis — MGE Pilot (design build) → Production
For: FohBoh dev team · Rev 2, 2026-08-30 · Now grounded in the Sentry v2 code review (`uploads/fohboh-sentry-Dev_sentryV2/` — Next.js 16 / React 19 / TS / PostgreSQL / Prisma 7)

## Headline (Rev 2)
Sentry v2 already IS the production platform for most of §§1–5 below: deterministic M01/M02 certification (TG gates with the same weights as the pilot's ledger — TG04=12 confirmed in tests), 198-rule registry as data, MQ6 persistence, CAARs + claim packs, DB-backed auth/roles/teams, location-scoped intake (CSV/PDF, hashing, schema governance), rate limiting, audit logs, SuperAdmin, migrations, and a real regression gate (`pnpm verify`, provider-aware CAAR scenarios). The build task is NOT green-field: it is (a) porting the pilot's v3 UX onto Sentry v2's view layer, and (b) closing the specific deltas listed below.

## Reuse vs rewrite verdicts (Rev 2)
- **Engine (`lib/mge/engine.ts`, `caar-engine.ts`, `certification/service.ts`)**: REUSE. Reconcile gate factor semantics against the pilot's golden fixtures (A 91 / D 87 / B 78 / C 88 / T 90) as CI tests; verify ROUND_HALF_UP normalization from 99 raw.
- **Data model (Prisma `*_v2` tables)**: REUSE. Covers customers/locations, uploads+blobs, cert runs, MQ6 scores, rule citations, CAARs, billing foundation, team access. Delta: append-only/immutability enforcement for vault-class tables, IUM metadata-only event stream as a first-class table.
- **Auth**: REUSE (bcrypt managers, signed HTTP-only sessions, roles incl. SuperAdmin, no shared admin password — already better than the pilot's demo locks). Delta: invitation-only onboarding + re-invite-instead-of-reset flow; EC as a personal capability with re-auth attestation.
- **Intake**: REUSE (schema matching, hashing, validation, vendor scoping). Delta: onboarding 5/5 gate as an API constraint; EC attest-and-seal step; 4 MB upload limit → direct-to-object-storage for larger statements (known limitation in their README).
- **Front-end (SentryApp/views)**: EVOLVE. v2 has working views (Dashboard, Upload Center, CAAR list, Billing, FAQ, Waterfall, SuperAdmin). The pilot v3 is the design target: re-skin + IA (sidebar tree, act-here/read-only grammar, slide-ins, Demo Mode, Data Fit, Engine Room, Doc Kits, THE PROOF). This is the main Claude Code workstream.
- **Cortex**: BUILD (not in v2). Advisor + ops AI behind Trust Wall 2, Data Fit dependency gate, 163-prompt registry, MGE Simulation. API contract №₂ must be read-only against `caars_v2` / `mq6_scores_v2` / vault tables.
- **Storage**: EVOLVE — blobs currently in PostgreSQL (`object_blobs_v2`); move evidence/ExportPacks to S3 object-lock (WORM) per §4.
- **Billing**: EXTEND — billing foundation tables exist; add Charter 15% / $199 / IUM-metered plans + invoice-to-run reconciliation from the pilot's Accounts Payable spec.

## Remaining true gaps (unchanged from Rev 1 where not struck)
1. Cortex product + Data Fit (build).
2. Open/partner API (contract №₁ exists implicitly as internal routes; publish versioned OpenAPI; SoR hash-verify receipt endpoint).
3. IUM as billing/telemetry instrument (metadata-only stream, T/D/R/E aggregates, FohBoh-website growth KPIs).
4. Vault immutability at storage layer (S3 object-lock) + ExportPack release approval workflow.
5. Determinism harness: run-twice byte-identical hash check in CI (pilot QA policy — v2 has scenario verification but not the twin-hash invariant).
6. Engine Room / Doc Kits / THE PROOF surfaces; Demo Mode; section slide-ins — pilot v3 spec.
7. Mobile Cortex (voice) — later phase.

## Claude Code plan (Rev 2)
Point Claude Code at the Sentry v2 repo (not a new scaffold) with: this doc, the pilot v3 file (UX spec), and the handoff README. Milestones: (1) golden-fixture tests locking the scoring contract; (2) v3 re-skin of SentryViewRouter views; (3) IUM stream + twin-hash CI; (4) Cortex + Data Fit service; (5) S3 object-lock migration; (6) partner API.


## Rev 1 body (assumed no production code existed — kept for reference; struck-through by Rev 2 verdicts above)

## What the pilot IS
A single-page design prototype (`MGE Pilot.dc.html`). All data is deterministic in-page fixtures (5 scenarios). No network, no persistence, no engine — the "runs," scores, hashes, spinners and approvals are scripted UI. Its value: the complete UX contract, vocabulary, math contract (TG01–TG10 → 99 → normalize), governance rules, and copy — a living spec the back-end must satisfy.

## Gap map (pilot → production)

### 1. Engine (the real MGE)
| Pilot | Production needs |
|---|---|
| Scores/penalties/gate factors hard-coded per scenario | MGE service executing the real contract: MQ6 observations → TG01–TG10 factors from persisted controls → raw/99 → ROUND_HALF_UP; 198-rule pack execution; DCLS v2.0 state machine; hard predicates that block regardless of score |
| SHA strings are literals | Real SHA-256 chain: file seal at intake, stage hashes, Merkle manifest, narrative hash (R145), byte-identical replay verification |
| "Re-run (deterministic)" replays fixtures | True determinism harness: frozen package versions, Decimal math, run-twice QA policy automated in CI |

### 2. API layer (none exists)
- API contract №1 (Sentry↔MGE): submit CEP, poll run state, receive sealed object. Contract №2 (Cortex↔MGE): read-only, TS≥85 enforcement server-side.
- Public/partner API for SoR receipts (hash-verify endpoint).
- Versioned OpenAPI spec; idempotent submission (a CEP resubmitted must not double-run).

### 3. AuthN / AuthZ (pilot: two hard-coded passwords, client-side)
- Real identity: invitation-only accounts, no self-registration, re-invite instead of password reset (per onboarding memo) — Cognito or equivalent.
- Roles Owner/Finance/Manager/Viewer + EC as a personal capability (matrix already specced on Account & People page — implement as policy, not UI).
- FohBoh Super Admin: full backend access EXCEPT vault contents/ExportPacks/client CAARs; break-glass with incident ref + logging. Session banner "all actions logged."
- The pilot's `pizza`/`FohBoh2026` gates are demo theater — replace entirely.

### 4. Data layer (none)
- AWS: client account DB (tenants, locations, users, roles), evidence object store (S3, WORM/object-lock for vault + ExportPacks), append-only KPI Vault (immutability enforced at storage layer, not policy), IUM event stream (metadata-only schema — LOG/REF/NEVER field policy already specced on IUM page).
- Multi-tenancy isolation; cross-tenant identity rejection at Stage 1.

### 5. Intake & custody (pilot: drop-zone mock)
- Real upload → hash-on-receipt → parser/classifier (bank vs vendor statement vs POS vs contract) → staging → EC attestation (re-auth speed bump) → batch seal.
- Onboarding gate as an actual constraint (intake API refuses until 5/5 confirmed).
- Contract terms vaulted once, reused until renegotiated.

### 6. Products on top
- Sentry: claims lifecycle, Action Gate execution (real .docx/email dispatch, three-strikes escalation), ExportPack release workflow (FohBoh approval loop).
- Cortex: real LLM behind Trust Wall 2 with Data Fit dependency resolution before answering (163-prompt registry as data), MGE Simulation service for what-ifs, voice on mobile.
- Billing: metering off IUM events (Charter 15% / $199 / headless), invoice generation reconciled to run refs.

### 7. Non-functional
- p95 pipeline <5s (pilot displays it; production must measure it), audit-grade logging, SOC 2 posture, retention windows (24-month), reduced-motion/a11y pass, FRE 803(6)/902(11) evidence discipline reviewed by counsel.

## What carries over as-is
The pilot is the spec: screen inventory (16 surfaces), sidebar tree, persona visibility rules, all copy/tooltips/slide-ins, the scoring contract + fixtures (use scenarios A/D/B/C/T as golden regression cases — expected scores 91/87/78/88/90 with exact penalty tables), doc kits as intake test fixtures, and the QA policy (run twice, stamp, deletable tests only).

## Can Claude Code build the production version?
Yes — realistically, with scope discipline. Claude Code in a terminal is the right tool to: scaffold the monorepo (engine service, API, web app), port the pilot's fixtures into golden tests, implement the TG scoring contract and DCLS state machine (pure deterministic code — its sweet spot), wire Cognito + S3 object-lock + Postgres/DynamoDB on AWS, and translate each pilot screen into the production front-end against the real API. What it does NOT remove: human decisions on infra accounts/keys, counsel review of the evidence claims, and the patent-sensitive parts you may want written by fewer hands. Recommended path: hand Claude Code (1) this GAP doc, (2) the pilot file as UX spec, (3) the Sentry v1 back-end repo you're about to share, and have it produce an architecture plan + milestone breakdown before writing code. The "Handoff to Claude Code" package can be generated from this project when you're ready.

## Open items pending the Sentry v1 code review
- What v1 already covers (auth? intake? parsing?) — this doc assumes nothing until reviewed.
- Whether v1's data model can host the KPI Registry/Vault or the engine needs its own store.
- Reuse vs. rewrite decision per module.
