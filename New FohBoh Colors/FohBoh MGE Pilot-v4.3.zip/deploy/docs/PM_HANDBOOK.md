# FohBoh | MGE™ Pilot — Product Manager's Handbook
v4.3 · 2026-09-02 · FohBoh internal · Confidential — subject to non-disclosure

## 1. What this product is
The FohBoh.ai Certified Intelligence Platform: two products on one engine.
- **MGE™ (Metrics Governance Engine)** — a deterministic, sector-agnostic certification engine: 13 technology elements, an 8-step pipeline (Resolve → Govern → Calculate → Reconcile → Test → Score → Determine → Seal), 198 governed rules. Patent-pending. Spinnable as a standalone engine at any time.
- **Sentry™** — the certification & recovery product (modules M01 Merchant Fee Recovery, M02 Delivery Fee Recovery). Feeds evidence to the engine via API contract №1.
- **Cortex™** — the AI advisor. Reads sealed results via API contract №2; answers only from certified domains.

**The architecture sentence:** AI prepares before (Trust Wall 1), AI explains after (Trust Wall 2) — the middle is pure engine. The Trust Score, findings and CAAR narrative are computed, not composed.

## 2. What we sell
Confidence, not a money tree. Some months find $0, others $4,729 — either way the operator holds certified proof instead of a spreadsheet opinion. The CAAR isn't a report; it's what makes the money collectable.

## 3. The client journey (v4.3)
1. **Invitation** — accounts exist by invitation only; the invited email is the username, always. Sign-up asks for a password and acceptance of Terms v3.2 / Privacy / Data Security Agreement (recorded, timestamped). No self-registration; no password resets — a locked-out user is re-invited.
2. **Welcome / START HERE** — full-screen first-run: ✓ account created → upload documents → we certify. Reachable later via Help → Quick start.
3. **Data Intake — five steps** — 1 choose module (M01/M02; sets the required-document list) · 2 drop documents *as issued* (PDF-first custody) · 3 receive/hash/stage (SHA-256 on receipt) · 4 AI prep validates at Trust Wall 1 · 5 the client's own Evidence Custodian attests & seals (a named person at the client, never FohBoh). Steps 3–5 are ours; the client's work ends at step 2 — that's the white-glove story.
4. **Run → Result → CAAR** — deterministic 8-step run; sealed score + penalty audit trail; CAAR issued at every score.
5. **Claims** — vendor disputes through Action Gates (human-authorized). Three strikes → outside counsel with the sealed evidence pack.
6. **Money** — invoices name their runs; below-85 runs listed at $0.

## 4. Modes (who sees what)
- **Client sign-in** (`MGEpilot@fohboh.com` / `pizza`): clean console. Money-first dashboard hero, four job cards (Upload / Claims / Guide / Support), job-grouped unnumbered menu (HOME / CERTIFY / RESULTS & RECORDS / ASK CORTEX / ACCOUNT / HELP). No scenario tabs, no personas, no DEMO MODE, no admin.
- **FohBoh sign-in** (`info@fohboh.com` / `FohBoh2026`): full showcase — numbered sidebar, scenario tabs, Client/FohBoh/SoR visibility toggle, DEMO MODE tour, unlocked Admin.
- **Explore the pilot**: guest showcase, admin locked (universal password `pizza` or `FohBoh2026`).

## 5. Scoring & outcomes
- **Trust Score measures evidence coverage, not accuracy.** A 91 = the evidence let the engine see that completely. Less blind, not more right.
- **Bands:** CERTIFIED 85–100 (S1/S3, fee accrues) · VERIFIED 70–84 (S2) · REVIEWED 60–69 (S4, bounded scope) · FAILED 0–59 (S6). Hard gates override any number (Scenario C: 88 → REVIEWED).
- **Internal math (FohBoh-locked):** gates TG01–TG10, 99 raw points (TG07 Fee legitimacy = 25); score = raw ÷ 99 × 100. Clients see the penalty audit trail — same math as itemized deductions with named fixes.
- **Gate vs. score:** a missing *required source* blocks the run (named, e.g. "Awaiting: settlement batch detail") — it never silently lowers a score. Coverage gaps *inside* admitted evidence lower the score via completeness (Scenario R: 74.8% coverage → 65; two artifacts recertify at ~89).
- Scores above 100 are structurally impossible (Scenario X: engine rejects its own malformed object).

## 6. Evidence & custody policy
- **PDF-first:** the document as issued (portal PDF) is the custody original — hashed on receipt, self-authenticating (FRE 902(11) posture), text-layer parse, never print-and-rescan. CSV/XLSX = reconciliation aids. POS/bank = P1 system feeds.
- **Required documents.** M01: processor statements · merchant processing agreement · bank deposit activity · settlement batch detail. M02: DSP statement · DSP merchant agreement · order-level fee detail · POS sales export · bank deposit activity. Agreements vault once, until renegotiated.
- **Twin-run QA (standing policy):** every test certification executes twice on identical evidence; the sealed objects must hash byte-identical. TEST RUN records are deletable by policy; real records never are.

## 7. CAAR & fees
- **CAAR = Certified Analysis & Audit Report** (the only expansion; ToS corrected 2026-09-02). Issued for every run at any score; sealed with SHA-256 + date-time stamp; append-only vault.
- **Fee only at CERTIFIED (TS ≥ 85)**, on certified recoverable. We charge for certainty, not for trying.
- **Legal posture:** business records (FRE 803(6)), self-authentication (902(11)/(13)/(14)), summaries of voluminous records (1006). A CAAR is not a legal opinion, audit, or recovery guarantee — ToS §5.
- **Pricing (post-Charter):** Sentry $199/mo + 10–15% recovery fee on sealed recoverable · Cortex $249/mo / 150 conversations · Suite $399/mo / 200 locations · −15% annual. Charter free through Sep 30.

## 8. Cortex & Data Fit governance
- Cortex answers only from domains certified at TS ≥ 85; refusals name the blocked domain. No evidence → no answer.
- Cortex prose is advisory; the deterministic penalty trail is authoritative for "what to fix." Under 85, gap advice comes from the sealed record, not AI judgment.
- Data Fit is the evidence-availability gate: 163 registered prompts, READY/PARTIAL/MISSING/BLOCKED, live dependency demo (toggle Labor off → 27 prompts degrade).

## 9. Data ownership boundaries (ToS v3.2)
- Customer owns Customer Data; each CAAR is generated exclusively from Customer Data + authorized third-party records (§5, explicit as of 2026-09-02).
- FohBoh owns Certification Records and IUM — metadata only, never the readable content of client records. "Data is processed, not possessed. Trust is exported; data is not."
- Customer indemnifies FohBoh for claims arising from Customer Data and permissions (§17); liability capped at 12 months' fees (§16).

## 10. Vocabulary rules (IP hygiene)
Public: deterministic rules, sealed evidence, certified facts, Trust Score, Trust Walls, CAAR.
Internal/partner ONLY — never customer-facing: **MQ6** (say "six quality dimensions"), **AIS**, **SmartLearn™**, **ActionSense™**. The TG ledger and IUM snapshot are FohBoh-locked surfaces.
Legal thresholds: NULL-launch — no S3 escalation until real volume sets values; S3 is labeling, not a legal act.

## 11. Demo playbook
- Best first demo: FohBoh sign-in → visibility "Client" → scenario B (the $4,729 recovery story).
- Scenario tabs (showcase only): T twin-run proof · A clean 91 · D near-threshold 87 · B Verified 78 · C override 88→REVIEWED · R bounded-scope 65 · F failed 54 · X invalid 105.
- Demo evidence sets: 9 synthetic PDFs in the Data Intake drop zone; in-app viewer + download. (v4.4 will make them look like real statements, math-reconciled.)
- **Ask FohBoh** (Admin): the internal answer desk — 23 curated Q&As; use it live when a question stumps you. Curated, not generated: it cannot misstate the patent story.
- 12-step guided tour = staff-run; clients get the User Guide, FAQ (26 Qs), and glossary (33 terms) in-console.
- Every figure is a deterministic fixture; totals reconcile across findings → CAAR → invoices (see docs/QA_CHECKLIST.md).

## 12. Surfaces inventory
Client-facing (11): Dashboard · Data Intake/CEP · Runtime/Result · Findings · CAAR · Vault · Action Gates/Claims · Cortex (+ Data Fit) · KPI Registry/Vault · Usage Log (IUM) · Messages / Accounts Payable / Account & People (incl. Your profile).
FohBoh Admin (4, universal password): Doc Kits & The Proof · API Connect & Configure · MGE™ Engine Room · Ask FohBoh.
Companions: Platform Overview one-pager · Cortex Mobile (iOS concept) · Site Map.

## 13. Roadmap / parked
- **v4.4 first item:** regenerate the 9 test-kit PDFs as realistic vendor-style documents, math-reconciled (Q1 → $4,729; M02 Jul → $2,010.80; agreement Exhibit A §4.2 2.40% ↔ F-201).
- **Candidate:** 90-second navigation video for the portal + console.
- Engineering: Phase-1 build (CORE-07/01/02/03/06 + fixtures); rules buildout from INST/Python; SEN-01–07 product layer; Cortex spec (CTX-02/04/06). See docs/ENGINEERING_HANDOFF.md.
- Finance/legal: real thresholds when counsel engages; FRSO taxonomy expansion; SOC-2 for diligence.

© 2026 FohBoh.ai, Inc. All rights reserved · Patent pending · Confidential, subject to non-disclosure
