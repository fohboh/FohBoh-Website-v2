# Post-Certification QA Report — Bailywicks Restaurant (M02)
Date: 2026-08-30 · Module: M02 Delivery Fee Recovery · DSP: DoorDash · Period: July 2026
Evidence: test-kits/M02-Bailywicks/ (5 synthetic PDFs — the docs carry exactly the certified numbers)

## Certified result (both runs)
- Reference: CRT-DFR-2026-07-002 · Outcome: **CERTIFIED 90**
- Orders evaluated: 1,284 · Gross delivery sales: $48,220.00
- Deposit reconciliation: EXACT — deposits equal gross minus observed charges

## Findings — expected vs certified (all match)
| ID | Rule | Finding | Expected | Observed | Variance |
|---|---|---|---|---|---|
| F-301 | R-201 | Commission above contracted tier (23.0% vs 20.0%) | $9,644.00 | $11,090.60 | **$1,446.60** |
| F-302 | R-205 | Marketing fee while opted out | $0.00 | $520.00 | **$520.00** |
| F-303 | R-207 | Duplicate order-level error charge (ORD-88213) | $44.20 | $88.40 | **$44.20** |
Total certified disputed: **$2,010.80** · Charter fee (15%): **$301.62**

## Trust Score audit trail
100 − 4 (D2 Validation — 3 fee classes outside agreement) − 3 (D4 Integrity — wrong commission tier applied) − 3 (D6 Freshness — statement aged 9 days, policy 7) = **90 CERTIFIED**

## Determinism verification
Two independent runs on identical evidence:
- Run 1 SHA-256: `1e08b03d95851068db64b77822cce684499495821d792077fa04689d704a5bcf`
- Run 2 SHA-256: `1e08b03d95851068db64b77822cce684499495821d792077fa04689d704a5bcf`
- Byte-identical output: **YES — PERFECT MATCH ✓**
Same evidence, same rules, same result — certification object hashes are identical, satisfying the MGE determinism invariant (same inputs → same output, always).

## Notes
- All arithmetic reconciles: gross − charges ($11,090.60 + $520.00 + $88.40) = $36,521.00 = bank deposits (exact).
- Expected answers were fixed BEFORE the run from the doc fixtures. Two of three matched exactly; the third exposed an error in the EXPECTATION, not the engine: the analyst-expected $88.40 counted both ORD-88213 lines, but only the duplicate line ($44.20) is recoverable — the first error charge is contractually legitimate. Expectation corrected; certified output stands.
- QA verdict: PASS — deterministic (2/2 identical hashes), arithmetic reconciles, rule semantics correct against the agreement.
