# FohBoh | MGE™ Pilot — Owner's Study Guide
For Michael and anyone demoing or evaluating the pilot · 2026-09-02 · covers `MGE Pilot v4.3.dc.html` (v4.2 and v4.1 retained as fallbacks)

## 1. The elevator story (memorize this)
**The question we answer:** "Are your numbers accurate? Can you prove it?"
**The one-liner:** MGE makes it safe, Sentry brings you money, Cortex gives certified answers.
**What we sell:** confidence, not a money tree. Some months find $0, others $1,945.10 — either way the operator holds certified proof instead of a spreadsheet opinion.
**The architecture in one breath:** Two products, one engine. The MGE is a deterministic, sector-agnostic certification engine (13 technology elements, 8-step pipeline, 198 rules). Sentry submits evidence through API contract №1; Cortex reads sealed results through contract №2. AI never touches certification — Trust Wall 1 before, Trust Wall 2 after.

## 2. Signing in (the pilot's demo credentials)
- Client: `MGEpilot@fohboh.com` / `pizza` → lands on the Dashboard as Riverside Grill's owner
- FohBoh admin: `info@fohboh.com` / `FohBoh2026` → lands as FohBoh persona with the Admin section already unlocked
- "Explore the pilot →" skips login to the Overview (for quick demos)
- The FohBoh Admin sidebar section (Doc Kits, API Connect, Engine Room) opens with either `pizza` or `FohBoh2026`; one unlock opens all three; LOCK re-seals.

## 3. The Trust Score — what you must be able to explain
- **It measures evidence coverage, not accuracy and not outcome quality.** A 91 doesn't mean "91% correct" — it means the evidence let the engine see and cross-check that completely. Less blind, not more right.
- **The math (internal):** ten scoring gates TG01–TG10 carry 99 raw points (TG07 Fee legitimacy is the biggest at 25). Score = raw ÷ 99 × 100, rounded. Clients never see gates or weights — they see the **penalty audit trail**: 100 basis → itemized deductions (points, reason, recommended fix) → sealed score.
- **MQ6** (never say it to clients — it's IP): the six diagnostic dimensions — Completeness, Consistency, Timeliness, Alignment, Reconciliation integrity, Governance adherence — that classify evidence observations feeding the gates.
- **Outcomes:** CERTIFIED 85–100 · VERIFIED 70–84 · REVIEWED 60–69 · FAILED 0–59. **Hard gates override the number** (Scenario C: scored 88, but no contract covered June 1–15 → REVIEWED. A score alone never certifies.)
- **Every run seals a CAAR** with a date-time stamp, whatever the score. The fee is earned only at 85+.
- A score above 100 is structurally impossible (the 105 scenario shows the engine rejecting its own bad object).

## 4. The five scenarios (header tabs) and what each demonstrates
| Tab | Story | Use it to show |
|---|---|---|
| T · Test run 90 | Bailywicks, M02/DoorDash, $2,010.80 | Determinism (run twice, identical hashes), the full test loop, QA correcting the analyst not the engine |
| A · Certified 91 | Clean month, $12.40 rounding variance | What "nothing wrong" looks like — confidence is the product |
| D · Certified 87 | Near-threshold, $34.80 | Small-dollar wins; what to fix to gain margin |
| B · Verified 78 | $4,729 leakage, 4 fee classes outside contract | The recovery story; why below-85 still gets a sealed report, charged nothing |
| R · Reviewed 65 | Riverside Aug 2026, coverage 74.8%, $120 in-scope variance | The natural 60–69 band (no override): certified on bounded scope; the two artifacts that recertify at ~89 |
| C · Reviewed 88→override | Contract gap June 1–15 | Governance beats arithmetic; hard gates |
| 105 | Invalid object rejected | The engine polices itself |

## 5. Walk the customer journey (sidebar order)
1. **Dashboard** — the home question, the two reasons clients come (see metrics / certify), the 8-step pipeline ribbon.
2. **Data Intake (3.2)** — the client's ONE job: drop files per FohBoh's instructions. Onboarding gate 5/5, hash-on-receipt, parser staging, Evidence Custodian attests & seals. "A gate is a constraint, not advice."
3. **Runtime (3.3)** — Resolve → Govern → Calculate → Reconcile → Test → Score → Determine → Seal. Deterministic; re-run gives the same result.
4. **Result** — score gauge, penalty trail (client view), TG ledger (FohBoh-locked), hard gates.
5. **Findings / CAAR (3.4–3.5)** — certified facts with evidence traces; the sealed 11-section instrument. CAAR exports anytime.
6. **Vault (3.6)** — CAAR + ExportPack pairs. ⬇ CAAR always; evidence packs release by FohBoh approval.
7. **Action Gates (3.7)** — nothing executes without human authorization. Vendor letters, three-strikes escalation.
8. **Cortex (4)** — ask anything; answers only from certified data (TS ≥ 85), every claim cited, refuses uncertified domains by name (try "Which items are my waste leaders?" — blocked on Inventory 72). **Data Fit (4.1)**: no evidence → no answer; toggle Labor off and watch 27 prompts degrade.
9. **KPI Registry / Vault (5)** — 50-KPI library → your customizations → immutable vault. Only vaulted definitions feed Cortex.
10. **Usage Log (6)** — metadata only, never restaurant data; the permanent proof governance occurred.
11. **Messages / Accounts Payable / Account & People (7–9)** — the desk, the invoices that name their runs (below-85 listed at $0), the role matrix whose last row is the product: *nobody edits the record.*

## 6. The interaction grammar
Sidebar squares: **■ solid = you act here** (Intake, Action Gates, Cortex, Messages, Account) · **□ hollow = sealed record, read-only**. White-glove: clients upload and approve; FohBoh does everything else. A self-guided tier comes later.

## 7. FohBoh-only surfaces (Admin section)
- **Doc Kits** — downloadable M01/M02 synthetic evidence sets + THE PROOF (the investor "so what": reproducibility, caught-the-human, evidence-not-analysis, cannot-be-negotiated-with, scales-the-judgment) + delete/restore the TEST run.
- **API Connect & Configure** — Cortex API status, environment, key, POS/DSP feeds (all still enter through intake custody).
- **MGE™ Engine Room** — the Lamborghini window: animated 8-step cycle, 13 element cards, SHA ticker, M01/M02 Vimeo links. Artifact view — not the live engine.

## 8. Answers to the hard questions
- **"So a spreadsheet could do this?"** It can find the overcharge. It cannot prove it found it correctly, prove it would find it identically tomorrow, or survive the vendor's lawyer asking who edited cell F14. Our product isn't the arithmetic — it's the proof.
- **"Can FohBoh raise my score?"** Nobody can. No write path exists — not support, not the AI, not the client. Only a new certification run.
- **"What if a vendor rejects the claim?"** Strike one of three. Three strikes → FohBoh refers to outside counsel with the sealed evidence pack.
- **"Who sees my data?"** You. Vendors see what you authorize. The SoR gets a hash-verifiable receipt. FohBoh keeps metadata only — and support can't open your vault.
- **"Why did my score drop?"** Read the penalty trail — every point below 100 has a named reason and a recommended fix. Fix, recertify; the new run supersedes, never rewrites.

## 9. What's new in v4.3 (demo it)
- **Two modes, persona-driven** — client sign-in = the clean console (money-first "You are owed" hero, four job cards, job-grouped unnumbered menu, zero demo chrome, no admin); FohBoh sign-in or Explore = the full showcase. One build, two dressings.
- **Invitation-first onboarding** — a fresh browser lands on Accept Invitation (as if from the email): password + terms acceptance → "Enter your console" → full-screen Welcome with a 3-step checklist and START HERE. Reachable later via Help → Quick start. Profile completion lives in Account & People (Your profile card).
- **The skin** — marketing-site grammar: warm paper ground, ink type, FohBoh-red pills and kickers, black panels; green reserved for money and CERTIFIED.
- **Data Intake = 5 numbered steps** — 1 choose module (sets the document list) · 2 drop documents · 3 we receive/hash/stage · 4 AI prep (Trust Wall 1) · 5 the client's own custodian attests & seals. Demo evidence sets (9 synthetic PDFs) open in an in-app viewer with Download.
- **Ask FohBoh** — 4th Admin surface (universal password): the internal answer desk. 23 curated Q&As × 7 topics, keyword ask-box, category chips. Never client-facing, no live AI — it cannot misstate the patent story. Use it when a demo question stumps you ("what happens at 9 of 10?").
- **"?" tooltips everywhere** — 15 boxes carry hover explainers in the 3-field pattern (what it is / does / why it matters), client and FohBoh sides, including IP guardrails on the TG ledger.
- **Scenario tabs** — two-line: letter + score over a sublabel (twin-run proof, the clean month, $4,729 recovery, hard-gate override…).
- **ToS v3.2 corrections** — CAAR = Certified **Analysis** & Audit Report everywhere; explicit client-data provenance sentence in §5; internal counsel note removed.

## 10. What's new in v4.2 (demo it)
- **Navigation** — sidebar is now a slide-in drawer: ☰ Menu pill bottom-left; logo click = Dashboard; **Sign out** at header right.
- **Header tools** — global search (⌕ CAARs, findings, KPIs, pages, glossary) and 🔔 notifications (seals, desk replies, evidence requests, invoices), post-login only.
- **Custody policy (PDF-first)** — upload documents *as issued* (portal PDF, text-layer parse, FRE 902(11)-style self-authentication); never print-and-rescan; CSVs are reconciliation aids; system feeds (POS/bank) are P1. Stated on Data Intake and woven through Scenario R, FAQ and fixtures.
- **Onboarding** — invitation-only accounts: email = username, password + required acceptance of Terms/Privacy/Data Security (timestamped). "Have an invitation?" on sign-in previews the flow (badged, grants no session). Guided-tour offer banner on guest entry.
- **Explainers** — CAAR "? What does each field mean" slide-in field guide; User Guide glossary (33 terms, category filter); FAQ expanded to 26 Qs in How-to / What-does-this-mean / How-do-I-know-if / General groups.
- **Data Fit** — Vimeo explainer video, two-column category coverage, architecture material folded behind "How Data Fit works", Cortex pill shows "3/4 datasets live".
- **Also** — Portfolio ⤓ Export CSV, print-ready CAAR export, Overview kicker follows the M01/M02 module toggle, MQ6 scrubbed from all client-facing copy (say "six quality dimensions").

## 11. Demo hygiene
- Demo Mode (sidebar) runs a 12-step guided tour — good default for first-time viewers. **The tour and this guide are for FohBoh demo staff, not client self-serve** — clients get the in-console User Guide, FAQ and glossary instead.
- Reset feel: pick scenario B, Client persona — the richest story.
- The QA policy stands: every test certification runs twice and must hash identical; test records are labeled TEST RUN and deletable; real records never are.
- Everything here is deterministic fixture data. Production status and the merge plan live in `docs/ENGINEERING_HANDOFF.md`.
