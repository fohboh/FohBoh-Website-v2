# FohBoh | MGE™ Pilot — static deploy bundle

Design pilot for FohBoh | Sentry™ + Cortex™ powered by the Metrics Governance Engine.
Pure static site — no build step, no server code.

## Deploy on Vercel
1. Push this folder to a GitHub repo (repo root = this folder).
2. Vercel → New Project → import the repo → Framework preset: **Other** → no build command, output dir `./`.
3. Done. `index.html` redirects to `MGE Pilot v3.dc.html`.

## Contents
- `index.html` — redirect to v3
- `MGE Pilot v3.dc.html` — light fintech theme (green #1a5f4a, current)
- `MGE Pilot.dc.html` — v2 blueprint original (preserved)
- `Site Map.dc.html`, `Cortex Mobile.dc.html` (+ `cortex-mobile-screen.jsx`, `ios-frame.jsx`)
- `support.js` — page runtime (required)
- `_ds/` — Industry design-system stylesheet + bundle (required)
- `test-kits/` — M01/M02 synthetic PDF evidence sets (linked from Doc Kits page)
- `docs/` — Bailywicks QA report + GAP analysis (linked in-app)

## Notes
- All data is deterministic in-page fixtures — no backend, no real credentials.
- Demo passwords are theater, not security: pilot `MGEpilot@fohboh.com`/`pizza`, admin `info@fohboh.com`/`FohBoh2026`, FohBoh Admin section unlocks with the universal password.
- Do not treat this as production; see `docs/GAP_ANALYSIS.md`.


## v4.2 (2026-09-01)
Current build: `MGE Pilot v4.2.dc.html` (index.html redirects here). v4.1 (`MGE Pilot v4.dc.html`) retained as fallback.
New in v4.2: scenario R (Reviewed 65), slide-in menu drawer + Sign out, global search + notifications, PDF-first custody policy (FRE 902(11)), CAAR field guide + blue score ring, glossary + expanded FAQ, Data Fit video (Vimeo) + compact category coverage, invitation-flow preview + Data Security Agreement acceptance, Portfolio CSV export, module-aware Overview.


## v4.3 (2026-09-02)
Current build: `MGE Pilot v4.3.dc.html` (index.html redirects here; v4.2 and v4.1 retained).
New: persona-driven Client mode vs Showcase mode; invitation-first onboarding + full-screen Welcome/START HERE; money-first client dashboard + job cards; job-grouped client menu; marketing-site skin (paper/ink/FohBoh-red, green = money/certified only); Data Intake as 5 numbered steps with module-aware document lists; demo evidence sets with in-app PDF viewer (`test-kits/` — REQUIRED at repo root); Ask FohBoh internal answer desk (Admin); scenario tab sublabels; 15 "?" tooltip explainers; Your profile card in Account & People; ToS v3.2 corrections (Certified Analysis & Audit Report).
